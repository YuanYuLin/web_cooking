import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';

import 'rxjs/add/operator/toPromise';

import { Gpio } from './gpio';

@Injectable()
export class GpioService {

  private headers = new Headers({'Content-Type': 'application/json'});
  private gpiosUrl = 'api/gpio';  // URL to web api

  constructor(private http: Http) { }

  getGpios(): Promise<Gpio[]> {
    return this.http.get(this.gpiosUrl)
      .toPromise()
      .then(response => response.json().data as Gpio[])
      .catch(this.handleError);
  }

  getGpio(port: number , pin: number): Promise<Gpio> {
    const url = `${this.gpiosUrl}/${port}/${pin}`;
    return this.http.get(url)
      .toPromise()
      .then(response => response.json().data as Gpio)
      .catch(this.handleError);
  }

  update(gpio: Gpio): Promise<Gpio> {
    const url = `${this.gpiosUrl}/${gpio.port}/${gpio.pin}`;
    return this.http
      .put(url, JSON.stringify(gpio), {headers: this.headers})
      .toPromise()
      .then(() => gpio)
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error); // for demo purposes only
    return Promise.reject(error.message || error);
  }
}
