import {Component, OnInit} from '@angular/core';
import {MdlModule} from '@angular-mdl/core';

@Component({
  selector: 'app-mdl',
  templateUrl: './mdl-template-dashboard/mdl.component.html'
})
export class MdlComponent implements OnInit {
  title = 'DashBoard';
  ngOnInit(): void {
  }
}
