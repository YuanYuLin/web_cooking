
import {Component, OnInit} from '@angular/core';
import { ViewChild,  AfterViewInit  } from '@angular/core';

@Component({
    selector: 'app-layout',
    templateUrl: 'layout.component.html',
    styleUrls: ['app.component.css']
})
export class LayoutComponent implements OnInit, AfterViewInit {

    title = 'System Infomation DashBoard';
  @ViewChild('container') private _container;
  public showMenu = false;

  ngOnInit(): void { }
  ngAfterViewInit () {
    setTimeout(() => {
      this.showMenu = true;
    }, 0);
      this._container._ngZone.onMicrotaskEmpty.subscribe(() => {
      this._container._updateStyles();
      this._container._changeDetectorRef.markForCheck();
    });
  }
}
