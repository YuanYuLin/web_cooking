import { InMemoryDbService } from 'angular-in-memory-web-api';
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
/**const heroes = [
      { id: 0,  name: 'core' },
      { id: 11, name: 'email' },
      { id: 12, name: 'home' },
      { id: 13, name: 'ui_configurability' },
      { id: 14, name: 'ui_configurability.management' },
      { id: 15, name: 'ui_configurability.pure' },
      { id: 16, name: 'ui_configurability.multiple_context' },
      { id: 17, name: 'corectms' },
      { id: 18, name: 'course' },
      { id: 19, name: 'course.online' },
      { id: 20, name: 'course.onlinetest' },
      { id: 21, name: 'course.classroom' },
      { id: 22, name: 'course.classroomtest' },
      { id: 23, name: 'course.external' },
      { id: 24, name: 'course.survey' }
    ];**/
   const gpio = [
     { type: 'gpio', pin: 0, port: 1, value: '1', direction : 'OUTPUT' , unix_timestamp: '123131' , comment: 'Note' , name: 'RY2' },
     { type: 'gpio', pin: 0, port: 26, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'DO_Y1' },
     { type: 'gpio', pin: 0, port: 27, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'LED2' },
     { type: 'gpio', pin: 1, port: 12, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'DO_Y0' },
     { type: 'gpio', pin: 1, port: 13, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'LED3' },
     { type: 'gpio', pin: 1, port: 14, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'DO_Y2' },
    { type: 'gpio', pin: 1, port: 15, value: '0', direction : 'OUTPUT' ,
     unix_timestamp: '12313135' , comment: 'Note' , name: 'LED1 (PWR)' },
     { type: 'gpio', pin: 1, port: 16, value: '0', direction : 'INPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'DI_X1' },
     { type: 'gpio', pin: 1, port: 17, value: '0', direction : 'INPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'DI_X2' },
     { type: 'gpio', pin: 1, port: 28, value: '0', direction : 'INPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'DI_X0' },
     { type: 'gpio', pin: 1, port: 19, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'LED4' },
     { type: 'gpio', pin: 2, port: 1, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'DO_Y3' },
     { type: 'gpio', pin: 3, port: 19, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'RY1' },
     { type: 'gpio', pin: 3, port: 21, value: '0', direction : 'OUTPUT' , unix_timestamp: '12313135' , comment: 'Note' , name: 'DI_X3' }
    ];
    return {gpio};
  }
}
