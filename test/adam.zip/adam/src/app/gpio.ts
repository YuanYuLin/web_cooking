export class Gpio {
  type: string;
  port: number;
  pin: number;
  value: string;
  direction: string;
  unix_timestamp: string;
  comment: string;
  name: string;
}
