import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { Gpio } from '../gpio';
import { GpioService } from '../gpio.service';

@Component({
  selector: 'app-mdl-dashboard',
  templateUrl: './mdl-dashboard.component.html',
  styleUrls: [ './mdl-dashboard.component.css' ]
})
export class MDLDashboardComponent implements OnInit {
  gpios: Gpio[];
  selectedGpio: Gpio;
  constructor(
    private gpioService: GpioService,
    private router: Router ,
    private location: Location
    ) { }

  getGpios(): void {
    this.gpioService.getGpios()
      .then(gpios => this.gpios = gpios);
  }

  onSelect(gpio: Gpio): void {
    this.selectedGpio = gpio;
  }

  save(gpio: Gpio): void {
    this.gpioService.update(gpio)
      .then(() => this.goBack());
  }

  goBack(): void {
    this.location.back();
  }
  ngOnInit(): void {
     this.getGpios();
  }
}
